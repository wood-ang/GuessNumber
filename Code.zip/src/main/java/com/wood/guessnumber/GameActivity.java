package com.wood.guessnumber;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class GameActivity extends AppCompatActivity {


    int Answer_int;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        setupEdgeToEdge();
        setupActionBar();
        setTextView();
        setZB();
        Answer_int = (int) (Math.random() * 1000);
        Input();
    }

    private void setupEdgeToEdge() {
        EdgeToEdge.enable(this);
        View mainView = findViewById(R.id.GameMain);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }
    }
    protected void setTextView(){
        findViewById(R.id.GZ).setOnClickListener(v -> {
            Intent intent = new Intent(GameActivity.this, GZActivity.class);
            startActivity(intent);
        });
    }

    @SuppressLint("RestrictedApi")
    private void setupActionBar() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("开始游戏");
        }
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);
    }
    private void Input(){
        // 处理输入
        EditText input = findViewById(R.id.inputNumber);
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {

                String numberString = input.getText().toString().trim();

                try {
                    int numberInt = Integer.parseInt(numberString);

                    if (Answer_int == numberInt) {
                        Toast.makeText(this, "猜对了...已生成新答案", Toast.LENGTH_SHORT).show();
                        Answer_int = (int) (Math.random() * 1000);
                    } else if (Answer_int < numberInt) {
                        Toast.makeText(this, "猜大了", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "猜小了", Toast.LENGTH_SHORT).show();
                    }

                } catch (NumberFormatException e) {
                    Toast.makeText(this, "你不乘哦", Toast.LENGTH_SHORT).show();
                }

                return true;
            }
            return false;
        });
    }

    protected void setZB(){
        findViewById(R.id.ZB).setOnClickListener(v -> {
            Toast.makeText(this, "告诉你答案是"+Answer_int+"呦", Toast.LENGTH_SHORT).show();
        });
    }
}